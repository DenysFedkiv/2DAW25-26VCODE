function crearNota() {
    let tituloNota = document.getElementById("tituloNota");
    let textNota = document.getElementById("textNota");
    let colorNota = document.getElementById("colorNota");
    let prioridadNota = document.getElementById("prioridadNota");
    let colorTexto = document.getElementById("colorTexto");

    let contNotas = document.getElementById("notasCont");
    let contNotasDest = document.getElementById("dest-notas");

    let nota = document.createElement("div");

    let notaTitulo = document.createElement("h2");
    notaTitulo.innerText = tituloNota.value;
    
    let notaTexto = document.createElement("p");
    notaTexto.innerText = textNota.value;

    nota.append(notaTitulo);
    nota.append(notaTexto);
    
    nota.classList.add("nota");
    nota.classList.add("nota" + colorNota.value);
    nota.style.color = colorTexto.value;
    
    if(prioridadNota.checked) {
        nota.classList.add("notaDest");
        contNotasDest.append(nota);
    }
    else {
        contNotas.append(nota);
    }

}